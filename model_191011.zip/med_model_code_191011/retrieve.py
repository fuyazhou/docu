import jieba
from gensim.summarization import bm25
import heapq
from match_func.match_func import match_class
import json
import os
from tqdm import tqdm
import re

# matcher = match_class('match_func/test.att', 'cpu')

jieba.load_userdict('wordlist/wordlist_icd11.txt')
# jieba.load_userdict('wordlist/wordlist_synonyms.txt')
# jieba.load_userdict('wordlist/A+医学百科药物名称.txt')
jieba.load_userdict('wordlist/大纲疾病列表.txt')
jieba.load_userdict('wordlist/durg_list.txt')

stopwords = []
for line in open('stopwords.txt'):
    stopwords.append(line.strip('\n'))

synonyms = {}
with open('wordlist/医学词汇别名-名字.txt') as f:
    for line in f:
        line = line.strip('\n').split(',')
        synonyms[line[0]] = line[1]
relation_word = json.load(open('wordlist/relation_words_count.挖掘复述词.json'))
for key in list(relation_word.keys())[:15]:
    for word, _ in relation_word[key][:3]:
        synonyms[word] = key


def replace_synonyms(sentence):
    for a, b in synonyms.items():
        sentence = sentence.replace(a, b)
    return sentence


filename = 'semi/medical.json'
semi = {}
for line in open(filename, encoding='utf8'):
    d = json.loads(line)
    d_dict = {}
    name = d['name']
    if 'desc' in d:
        d_dict['描述'] = d['desc']
    if 'prevent' in d:
        d_dict['预防'] = name + '预防：' + d['prevent']
    if 'cause' in d:
        d_dict['病因'] = name + '病因：' + d['cause']
    if 'symptom' in d:
        d_dict['症状'] = name + '症状：' + '、'.join(d['symptom'])
    if 'cure_way' in d:
        d_dict['治疗方法'] = name + '治疗方法：' + '、'.join(d['cure_way'])
    if 'check' in d:
        d_dict['检查'] = name + '需要做的检查：' + '、'.join(d['check'])
    if 'recommand_drug' in d:
        d_dict['药物'] = name + '的推荐药物：' + '、'.join(d['recommand_drug'])
    semi[d['name']] = d_dict
semi_msd = json.load(open('semi/msd_semi.json'))
for key in semi_msd:
    if key in semi:
        for subkey in semi_msd[key]:
            if subkey in semi[key]:
                semi[key][subkey] += semi_msd[key][subkey]
            else:
                semi[key][subkey] = semi_msd[key][subkey]
    else:
        semi[key] = semi_msd[key]
semi_hyc = json.load(open('semi/HYC_Table_structure.json'))
temp = {}
for d in semi_hyc:
    for key in d:
        temp[key] = d[key]
semi_hyc = temp

wlist_病因 = []
wlist_药物 = []
wlist_症状 = []
wlist_疾病 = []
wlist_部位 = []
for fname in os.listdir('wordlist/分类词表/icd11/病因'):
    for _, w in json.load(open('wordlist/分类词表/icd11/病因/' + fname)):
        wlist_病因.append(w)
for fname in os.listdir('wordlist/分类词表/icd11/药物'):
    for _, w in json.load(open('wordlist/分类词表/icd11/药物/' + fname)):
        wlist_药物.append(w)
for w in open('wordlist/A+医学百科药物名称.txt'):
    wlist_药物.append(w.strip('\n'))
for w in open('wordlist/durg_list.txt'):
    wlist_药物.append(w.strip('\n'))
for fname in os.listdir('wordlist/分类词表/icd11/症状'):
    for _, w in json.load(open('wordlist/分类词表/icd11/症状/' + fname)):
        wlist_症状.append(w)
for fname in os.listdir('wordlist/分类词表/icd11/疾病'):
    for _, w in json.load(open('wordlist/分类词表/icd11/疾病/' + fname)):
        wlist_疾病.append(w)
for fname in os.listdir('wordlist/分类词表/icd11/部位'):
    for _, w in json.load(open('wordlist/分类词表/icd11/部位/' + fname)):
        wlist_部位.append(w)


class model(object):
    def __init__(self):
        self.passages = []
        with open('text/题库.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.passages.append(line.replace('(    )', '').replace('(   )', '').replace('（  ）。', ''))

        self.texts = []
        with open('text/HYC_Text.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace('*', ''))
        with open('text/msd.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace('*', ''))
        with open('text/med.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace('*', ''))
        with open('text/medbook.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace('*', ''))
        with open('text/HYC_Table_knowledge.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace('*', ''))
        with open('text/医师资格考试“最”相关知识点.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace(
                        '*', '').replace(' ', ''))
        with open('text/SuJi_text.txt', encoding='utf8') as f:
            for line in f.readlines():
                line = line.strip('\n')
                if len(line) != 0:
                    self.texts.append(line.replace('#', '').replace(
                        '*', '').replace(' ', ''))
        temp = []
        for p in tqdm(self.passages):
            if p not in temp:
                temp.append(p)
        self.passages = temp
        temp = []
        for p in tqdm(self.texts):
            if p not in temp:
                temp.append(p)
        self.texts = temp

        corpus = []
        for p in tqdm(self.passages):
            t = []
            for word in jieba.lcut(replace_synonyms(p)):
                if word not in stopwords:
                    t.append(word)
            corpus.append(t)
        self.bm25Model = bm25.BM25(corpus)
        self.average_idf = sum(map(lambda k: float(self.bm25Model.idf[k]), self.bm25Model.idf.keys())) / len(
            self.bm25Model.idf.keys())

        corpus = []
        for p in tqdm(self.texts):
            t = []
            for word in jieba.lcut(replace_synonyms(p)):
                if word not in stopwords:
                    t.append(word)
            corpus.append(t)
        self.bm25Model_t = bm25.BM25(corpus)
        self.average_idf_t = sum(map(lambda k: float(self.bm25Model_t.idf[k]), self.bm25Model_t.idf.keys())) / len(
            self.bm25Model_t.idf.keys())

    def bm25_top5(self, query, n=5, exception=None):
        scores = self.bm25Model.get_scores(query, self.average_idf)
        passage_search = []
        scores_top = heapq.nlargest(n + 1, scores)
        for s in scores_top:
            passage_search.append(self.passages[scores.index(s)])
            scores[scores.index(s)] = -1e20
        if exception:
            if exception in passage_search:
                passage_search.remove(exception)

        return passage_search[:n]

    def bm25_top5_t(self, query, n=5):
        scores = self.bm25Model_t.get_scores(query, self.average_idf_t)
        passage_search = []
        scores_top = heapq.nlargest(n, scores)
        for s in scores_top:
            passage_search.append(self.texts[scores.index(s)])
            scores[scores.index(s)] = -1e20
        return passage_search

    # def reranking(self, search_result, question, n=5):
    #     q = [question] * len(search_result)
    #     scores = matcher.match_score(q, search_result).tolist()
    #     passage_search = []
    #     scores_top = heapq.nlargest(n, scores)
    #     for s in scores_top:
    #         passage_search.append(search_result[scores.index(s)])
    #     return passage_search

    def expand_word(self, sentence):
        flag_病因 = False
        flag_药物 = False
        flag_症状 = False
        s = sentence.copy()
        for word in s:
            if word in wlist_病因:
                flag_病因 = True
            if word in wlist_药物:
                flag_药物 = True
            if word in wlist_症状:
                flag_症状 = True
        if flag_病因:
            s.append('病因')
        if flag_药物:
            s.append('药物')
        if flag_症状:
            s.append('症状')
        return ''.join(s)

    def semi_find(self, q, i=5):
        passage = []
        q = self.expand_word(q)
        for key in list(semi.keys()):
            if key in q:
                d = semi[key]

                if '预防' in d:
                    wordlist = ['预防', '避免']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['预防'])
                            break

                if '病因' in d:
                    wordlist = ['病因', '原因', '病理', '致病']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['病因'])
                            break

                if '原因' in d:
                    wordlist = ['病因', '原因', '病理', '致病']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['原因'])
                            break

                if '症状' in d:
                    wordlist = ['症状', '表现', '体征']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['症状'])
                            break

                if '治疗' in d:
                    wordlist = ['治疗', '方案', '方法', '手段', '药']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['治疗'])
                            break

                if '检查' in d:
                    wordlist = ['检查', '检验']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['检查'])
                            break

                if '药物' in d:
                    wordlist = ['治疗', '方案', '方法', '手段', '药']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['药物'])
                            break

                if '预后' in d:
                    wordlist = ['预后']
                    for word in wordlist:
                        if word in q:
                            passage.append(d['预后'])
                            break
        for key in list(semi_hyc.keys()):
            if key in q:
                d = semi_hyc[key]
                for subkey in d:
                    if subkey in q:
                        passage.append(d[subkey])
        if len(passage) == 0:
            for key in list(semi.keys()):
                if key in q:
                    d = semi[key]
                    for subkey in d:
                        if subkey in q:
                            passage.append(d[subkey])
        if len(passage) == 0:
            for key in list(semi.keys()):
                if key in q:
                    d = semi[key]
                    try:
                        passage.append(d['描述'])
                    except:
                        pass
        return passage[:i]

    def sentence_cut(self, sent):
        temp = re.split('[。！？!?\t\n]', sent)
        ret = []
        for s in temp:
            if len(s) != 0:
                ret.append(s.strip())
        return ret

    def cut(self, query_str):
        query = []
        for word in jieba.lcut(query_str.strip()):
            if word not in stopwords:
                if word in synonyms:
                    word = synonyms[word]
                query.append(word)
        return query

    def remove_dup(self, l):
        ret = []
        for item in l:
            if item not in ret:
                ret.append(item)
        return ret

    def bm25_reranking(self, query, slist, n=5):
        corpus = []
        for p in slist:
            corpus.append(jieba.lcut(p))
        bm25Model_t = bm25.BM25(corpus)
        average_idf_t = sum(map(lambda k: float(
            bm25Model_t.idf[k]), bm25Model_t.idf.keys())) / len(bm25Model_t.idf.keys())

        scores = bm25Model_t.get_scores(query, average_idf_t)
        passage_search = []
        scores_top = heapq.nlargest(n, scores)
        for s in scores_top:
            passage_search.append(slist[scores.index(s)])
            scores[scores.index(s)] = -1e20
        return passage_search, scores_top

    def sentence_selection_bm25(self, ans, results):
        sentences = []
        for result in results:
            if result.find('：') != -1:
                title = result.split('：')[0]
                result = ''.join(result.split('：')[1:])
            else:
                title = ''
            result_cut = self.sentence_cut(result)
            if len(result_cut) <= 3:
                sentences.append(title + result)
            else:
                for sent in result_cut:
                    if len(sent) < 10:
                        continue
                    sentences.append(title + sent)
        ret, _ = self.bm25_reranking(ans, sentences)

        return ret

    def run(self, question, candidates):
        passage_ans = []
        text_ans = []
        question_cut = self.cut(question)
        for ans in candidates:
            query = question_cut + self.cut(ans)
            # passage_s = self.reranking(self.bm25_top5(ans, 10), question)
            passage_s = self.remove_dup(self.bm25_top5(query, n=8))[:5]
            passage_ans.append(passage_s)
            # passage_s = self.reranking(self.bm25_top5_t(ans, 10), question)
            passage_s = self.remove_dup(self.semi_find(query) + self.bm25_top5_t(query, n=7))[:5]
            passage_s = self.sentence_selection_bm25(ans, passage_s)
            text_ans.append(passage_s)

        return passage_ans, text_ans
