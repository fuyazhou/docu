# # 封装给边宁

# In[23]:


import re
import json


def load_name2abbre(filename):
    name2abbre = json.load(open(filename, 'r', encoding='utf-8'))
    return name2abbre


def load_name2value_range(filename):
    name2value_range = json.load(open(filename, 'r', encoding='utf-8'))
    return name2value_range


def characters_normalize(q, name2abbre):
    pairs = []
    pairs = [
        ('．', '.'),
        ('％', '%'),
        ('／', '/'),
        ('\(\++\)，?', '异常，'),
        ('（\++），?', '异常，'),
        ('\(-+\)，?', '正常，'),
        ('（-+），?', '正常，'),
    ]

    for p in pairs:
        q = re.sub(p[0], p[1], q)
    return q


def manual_normailize(q, pv_pairs):
    for [p, value_range] in pv_pairs:
        results = p.findall(q)
        if results:
            for x in results:
                name = x[1]
                value = x[2]
                v = judge(value, value_range)
                q = q.replace(x[0], name + v)
    return q


def judge(value, value_range):
    if value[-1] == '%':
        value = float(value[:-1]) / 100
    else:
        try:
            value = float(value)
        except:
            value = value
    if type(value_range) == str and type(value) == str:
        if value == value_range:
            return '正常'
        else:
            return '异常'
    elif type(value_range) == list and (type(value) == float or type(value) == int):
        if value < value_range[0]:
            return '偏低'
        elif value > value_range[1]:
            return '偏高'
        else:
            return '正常'


def decide(abbre, value, abbre2name, name2value_range):
    name = None
    v = None
    if abbre.encode('utf-8').isalpha():
        for n, a in abbre2name.items():
            if a.lower() == abbre.lower():
                name = n
                break
    else:
        name = abbre
    if name in name2value_range:
        v = judge(value, name2value_range[name])
    return name, v


def normalize(q, abbre2name, name2value_range):
    p1 = re.compile('(([a-zA-Z]+)(:|：|\s+)?(\d+(\.\d+)?%?).*?)，')
    results = p1.findall(q)
    if results:
        for res in results:
            abbre, value = res[1], res[3]
            name, value = decide(abbre, value, abbre2name, name2value_range)
            if name and value:
                q = q.replace(res[0], name + value + '，' + res[0])
    return q


pv_pairs = [
    [re.compile('((心率)(\d+)(次/分)?)'), [60, 100]],
    [re.compile('((体温)(\d+(\.\d+)?)(℃)?)'), [36, 37]],
    [re.compile('((血压)(\d+)(.*?mmHg)?)'), [80, 140]],
    [re.compile('((脉搏)(\d+)(次/分)?)'), [60, 100]],
    [re.compile('((呼吸)(\d+)(次/分)?)'), [12, 20]],
]
abbre2name_filename = '化验项目缩写.json'
name2value_range_filename = '指标范围.json'
name2abbre = load_name2abbre(abbre2name_filename)
name2value_range = load_name2value_range(name2value_range_filename)
resource = (name2abbre, name2value_range, pv_pairs)


def process_line(line):
    name2abbre, name2value_range, pv_pairs = resource
    line = characters_normalize(line, name2abbre)
    line = normalize(line, name2abbre, name2value_range)
    line = manual_normailize(line, pv_pairs)
    return line


# In[25]:

if __name__ == "__main__":
    line = '女性实验室检查血WBC13.4×10⁹/L，N0.89，P89%，Hb104g/L，僵1年余，血RF：40（+），ESRl00mm/h，本患者目前暂不考虑的治疗措施是'

    x = process_line(line)
    print(line)
    print(x)
