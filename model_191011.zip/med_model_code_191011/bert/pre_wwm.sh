dir=`ls ../../med/extra_text`
for i in $dir
do
	echo $i 
	python create_pretraining_data_chinese.py --input_file=../../med/extra_text/$i --output_file=./tmp_extra_wwm/$i.tfrecord --vocab_file=../chinese_L-12_H-768_A-12/vocab.txt --do_lower_case=True --max_seq_length=128 --max_predictions_per_seq=20 --masked_lm_prob=0.15   --random_seed=12345   --dupe_factor=5   --do_whole_word_mask=True
done
