import requests
import json

# url = 'http://10.20.222.192:8003/medical/segment'
url = 'http://106.37.179.180:8003/medical/segment'


def ner_post(input):
    args = {"sentence": input}
    post_result = requests.post(url, data=json.dumps(args))
    return json.loads(post_result.text)['output']


if __name__ == "__main__":
    sentence = "患者李二明既往有高血压病史3年余,平素服用厄贝沙坦及氨氯地平缓释片降压，血压控制尚可"
    print(ner_post(sentence))

