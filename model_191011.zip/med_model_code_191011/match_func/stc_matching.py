import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
import jieba
import numpy as np
import sys
from torch.nn.utils.rnn import PackedSequence, pad_packed_sequence, pack_padded_sequence
from torch.autograd import Variable

def input_mask(li,padding=0):
    '[[1,2,3],[2,3]] -> [[1,2,3],[2,3,0]] , [[1,1,1],[1,1,0]]'
    bs = len(li)
    maxLen = max([len(s) for s in li])
    inp = np.zeros((bs,maxLen),dtype=int)
    mask = np.zeros((bs,maxLen),dtype=int)
    for i in range(len(li)):
        inp[i,:len(li[i])] = li[i]
        mask[i,:len(li[i])] = 1
    return inp,mask

class tokenizer(object):
    def __init__(self,vocabName=None,eos=None,unk=None):
        super(tokenizer, self).__init__()
        self.vocList = []
        self.vocDict = {}
        if vocabName is not None:
            self.getVocab(vocabName)    
        for w in [eos, unk]:
            if w is not None and w not in self.vocList:
                self.vocList.append(w)
                self.vocDict[w] = len(self.vocDict)
        self.eos = eos
        self.unk = unk
        return

    def getVocab(self,vocabName):
        if vocabName.endswith('.json'):
            pass
        elif vocabName.endswith('.pkl'):
            pass
        else:
            vocabList = []
            vocabDict = {}
            i = 0
            f = open('match_func/'+vocabName,encoding='utf8')
            if vocabName.endswith('.vec'):
                f.readline() # skip the first line
            for line in f:
                word = line.strip().split()[0]
                vocabList.append(word)
                vocabDict[word] = i
                i += 1
        self.vocList,self.vocDict = vocabList,vocabDict
        return True

    def makeVocab(self,fileName,minCnt = 0,vocSize = 0):
        w_f = {}
        cntAll = 0
        cntLine = 0
        for line in open(fileName):
            words = line.strip().split()
            for word in words:
                f = w_f.get(word,0)
                w_f[word] = f + 1
                cntAll += 1
            cntLine += 1
        print ('count of lines:',cntLine)
        print ('count of words:',cntAll)
        w_f = sorted(w_f.items(), key=lambda d: -d[1]) 

        if minCnt > 0:
            w_f = filter(lambda d: d[1] >= minCnt,w_f)

        if vocSize > 0: # vocSize <= 0 means, don't restrict the voc size
            w_f = w_f[:vocSize]

        return [d[0] for d in w_f]

    def saveVocab(self,fw):
        vocList = self.vocList
        fout = open(fw,'w')
        for word in vocList:
            fout.write(word+'\n')
        fout.close()

    def tokenize(self,stc):
        return list(jieba.cut(stc))

    def convert_tokens_to_ids(self,words,eos=None,unk=None):
        eos = eos if eos else self.eos
        unk = unk if unk else self.unk
        if type(words) == str:
            words = words.strip().split()
        voc = self.vocDict
        if eos and (len(words) == 0 or words[-1] != eos):
            words.append(eos)
        if unk:
            ids = [voc[w] if w in voc else voc.get(unk) for w in words]
        else:
            ids = [voc[w] for w in words if w in voc]
        return ids

    def convert_ids_to_tokens(self,ids):
        return [self.vocList[i] for i in ids]

class rnnEncoder(nn.Module):

    def __init__(self, vocSize, wordDim, hiddenDim, dropout = 0, bidirc = True, num_layers = 1):
        super(rnnEncoder, self).__init__()

        self.wordEmbedding = nn.Embedding(vocSize, wordDim)
        self.rnn = nn.GRU(wordDim, hiddenDim, dropout = dropout, bidirectional=bidirc, num_layers=num_layers)

        #self.h0 = Variable(torch.zeros(self.rnn.num_layers * (bidirc + 1), 1,self.rnn.hidden_size))
        #weight = next(self.parameters()).data
        #self.h0 = Variable(weight.new(self.rnn.num_layers * (bidirc + 1), 1,self.rnn.hidden_size).zero_())
        self.hdim_all = self.rnn.num_layers * (bidirc + 1) * self.rnn.hidden_size
        self.hiddenZerosDict = {}

    def get_h0(self, bsz=1):
        rt = self.hiddenZerosDict.get(bsz,None)
        if rt is not None:
            return rt
        else:
            weight = next(self.parameters()).data
            num_directions = 2 if self.rnn.bidirectional else 1
            rt =  Variable(weight.new(self.rnn.num_layers * num_directions,
                        bsz,self.rnn.hidden_size).zero_())
            #if self.rnn_type == 'LSTM':
            #    rt = (rt,rt)
            self.hiddenZerosDict[bsz] = rt
            return rt

    def forward_stc(self,input_seqs):
        embeds = self.wordEmbedding(input_seqs)
        embeds = embeds.view(len(input_seqs), 1, -1) # add batchSize dim

        enc, hn = self.rnn(embeds,self.get_h0(1))
        return enc,hn

    def forward(self, input_seqs):
        if isinstance(input_seqs, tuple) or isinstance(input_seqs, list):
            pass
        if isinstance(input_seqs, PackedSequence):
            #print (input_seqs)
            pad_seqs,lens = pad_packed_sequence(input_seqs,batch_first=True)
            #print (pad_seqs,lens)
            embeds = self.wordEmbedding(pad_seqs)
            #print (embeds.size())
            embeds = pack_padded_sequence(embeds,lens,batch_first=True)
            enc, hn = self.rnn(embeds,self.get_h0(len(lens)))
            hn = hn.transpose(0,1).contiguous() # hn.size = (batchSize,direction,hidden_dim)
            return enc,hn
        else: # just a stc
            return self.forward_stc(input_seqs)

class stc_matching_hmean(nn.Module):
    def __init__(self,**option):
        super(stc_matching_hmean, self).__init__()
        self.svsize = option["vocSize"]
        self.wordDim = option["embdim"]
        self.hiddenDim = option["hidden"]
        self.outDim = option["outhid"]

        self.encoder = rnnEncoder(self.svsize, self.wordDim, self.hiddenDim, bidirc=option['bidirc'])
        self.hiddenDimAll = self.hiddenDim * (int(option['bidirc']+1))
        self.prjLinear = nn.Linear(self.hiddenDimAll,self.hiddenDimAll)
        #self.prjLinear = nn.Linear(self.hiddenDimAll*4,self.outDim)
        #self.prjcLinear = nn.Linear(hdim,hhdim)

        # optimizer and training        
        self.lf = nn.NLLLoss()
        self.alpha = option["alpha"]
        #self.optimizer = optim.Adam(self.parameters(), lr=option["alpha"])#, betas=(0.9, 0.999) )
        #self.optimizer = optim.Adam ([{'params': self.bertModel.parameters(), 'lr':0.00002},
        #                              {'params': self.prjLinear.parameters()},
        #                              {'params': self.prjcLinear.parameters()}] , lr=0.001 ) #(self.parameters(), lr=0.00002) #, betas=(0.9, 0.999) )
        #self.optimizer = BertAdam(self.parameters(),
                                     # lr=0.00005, # 0.000005
                                     # warmup=0.1,
                                     # t_total=total_step)
        #self.optimizer.zero_grad()

        # select gpu/cpu mode for model and dataType
        d = option["device"].lower().replace('gpu','cuda')
        self.inited = False 
        self.use_cuda = False
        self.LongTensor = torch.LongTensor
        self.device = torch.device(d)
        if "cuda" in d or "gpu" in d:
            self.use_cuda = True

    def init(self):
        if self.inited:
            return
        self.optimizer = optim.Adam(self.parameters(), lr=self.alpha)
        self.optimizer.zero_grad()
        if torch.cuda.is_available() and self.use_cuda:
            sys.stdout.write("Using cuda~ on device " + str(self.device) + "\n")
            # model into gpu
            self.to(self.device)
            # data type for gpu
            self.LongTensor = torch.cuda.LongTensor
            self.toDevice = lambda x: x.to(self.device) #x.cuda()
        else:
            self.toDevice = lambda x: x
        self.inited = True
        def toNumpyArr(var):
            return var.data.cpu().numpy()
        self.toNumpyArr = toNumpyArr
        return

    def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
        # assert( len(stcX) * 5 == len(stcYs) ) # the batch_size
        # if right is not None:
        #     assert( len(stcX) == len(right) )
        # answer_num = len(stcYs[0])

        x_hs,x_hn = self.encoder(x_packed)
        y_hs,y_hn = self.encoder(ys_packed)

        x_hs,x_lens = pad_packed_sequence(x_hs,batch_first=True)
        x_hs,x_lens = x_hs[xi],x_lens[xi]
        y_hs,y_lens = pad_packed_sequence(y_hs,batch_first=True)
        ys_hs,ys_lens = y_hs[ysi],y_lens[ysi]
        #print (x_hs,x_lens) #x_hs.size = batch_size , max_len, hidden_dim_all
        x_hmean = x_hs.mean(-2)
        ys_hmean = ys_hs.mean(-2)
        x_hmean = torch.sigmoid(self.prjLinear(x_hmean))

        scores = x_hmean[:,None,:] * ys_hmean
        scores = scores.mean(-1) # batch_size x 5
        scores = F.log_softmax(scores,dim = -1)
        #print (scores.size(),right.size())

        if right is not None:
            if polar:
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                #scores = scores*(negs*(-2)+1)[:,None]
                scores = scores*(nidx*(-2)+1)
            return self.lf(scores,right)
        else:
            if polar:
                #nidx = scores.data < np.log(0.2)
                #scores[nidx] = 1/scores[nidx]
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                scores = scores*(negs*(-2)+1)[:,None]
            return scores

class stc_matching_hn(nn.Module):
    def __init__(self,**option):
        super(stc_matching_hn, self).__init__()
        self.svsize = option["vocSize"]
        self.wordDim = option["embdim"]
        self.hiddenDim = option["hidden"]
        self.outDim = option["outhid"]

        self.encoder = rnnEncoder(self.svsize, self.wordDim, self.hiddenDim, bidirc=option['bidirc'])
        self.hiddenDimAll = self.hiddenDim * (int(option['bidirc']+1))
        self.prjLinear = nn.Linear(self.hiddenDimAll,self.hiddenDimAll)
        #self.prjLinear = nn.Linear(self.hiddenDimAll*4,self.outDim)
        #self.prjcLinear = nn.Linear(hdim,hhdim)

        # optimizer and training        
        self.lf = nn.NLLLoss()
        self.alpha = option["alpha"]
        #self.optimizer = optim.Adam(self.parameters(), lr=option["alpha"])#, betas=(0.9, 0.999) )
        #self.optimizer = optim.Adam ([{'params': self.bertModel.parameters(), 'lr':0.00002},
        #                              {'params': self.prjLinear.parameters()},
        #                              {'params': self.prjcLinear.parameters()}] , lr=0.001 ) #(self.parameters(), lr=0.00002) #, betas=(0.9, 0.999) )
        #self.optimizer = BertAdam(self.parameters(),
                                     # lr=0.00005, # 0.000005
                                     # warmup=0.1,
                                     # t_total=total_step)
        #self.optimizer.zero_grad()

        # select gpu/cpu mode for model and dataType
        d = option["device"].lower().replace('gpu','cuda')
        self.inited = False 
        self.use_cuda = False
        self.LongTensor = torch.LongTensor
        self.device = torch.device(d)
        if "cuda" in d or "gpu" in d:
            self.use_cuda = True

    def init(self):
        if self.inited:
            return
        self.optimizer = optim.Adam(self.parameters(), lr=self.alpha)
        self.optimizer.zero_grad()
        if torch.cuda.is_available() and self.use_cuda:
            sys.stdout.write("Using cuda~ on device " + str(self.device) + "\n")
            # model into gpu
            self.to(self.device)
            # data type for gpu
            self.LongTensor = torch.cuda.LongTensor
            self.toDevice = lambda x: x.to(self.device) #x.cuda()
        else:
            self.toDevice = lambda x: x
        self.inited = True
        def toNumpyArr(var):
            return var.data.cpu().numpy()
        self.toNumpyArr = toNumpyArr
        return

    def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
        # assert( len(stcX) * 5 == len(stcYs) ) # the batch_size
        # if right is not None:
        #     assert( len(stcX) == len(right) )
        # answer_num = len(stcYs[0])

        x_hs,x_hn = self.encoder(x_packed)
        y_hs,y_hn = self.encoder(ys_packed)

        x_hn = x_hn.view(x_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        y_hn = y_hn.view(y_hn.size(0),-1)
        x_hn = torch.sigmoid(self.prjLinear(x_hn))

        #print (x_hn.size(),y_hn.size())
        #print (xi.size(),ysi.size())
        x_hn = x_hn[xi]
        ys_hn = y_hn[ysi] # (batch_size*5, 2*hidden_dim) --> ( batch_size, 5, 2*hidden_dim)
        #print (x_hn.size(),ys_hn.size())

        scores = x_hn[:,None,:] * ys_hn
        scores = scores.mean(-1) # batch_size x 5
        scores = F.log_softmax(scores,dim = -1)
        #print (scores.size(),right.size())

        if right is not None:
            if polar:
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                #scores = scores*(negs*(-2)+1)[:,None]
                scores = scores*(nidx*(-2)+1)
            return self.lf(scores,right)
        else:
            if polar:
                #nidx = scores.data < np.log(0.2)
                #scores[nidx] = 1/scores[nidx]
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                scores = scores*(negs*(-2)+1)[:,None]
            return scores
            
    def get_similar(self,stc1_packed,stc2_packed, s1i, s2i):
        
        s1_hs,s1_hn = self.encoder(stc1_packed)
        s2_hs,s2_hn = self.encoder(stc2_packed)        

        s1_hn = s1_hn.view(s1_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        s2_hn = s2_hn.view(s2_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        s1_hn = s1_hn[s1i]
        s2_hn = s2_hn[s2i]

        return self.toNumpyArr((s1_hn*s2_hn).mean(-1))

    # def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
    #     # assert( len(stcX) * 5 == len(stcYs) ) # the batch_size
    #     # if right is not None:
    #     #     assert( len(stcX) == len(right) )
    #     # answer_num = len(stcYs[0])

    #     x_hs,x_hn = self.encoder(x_packed)
    #     y_hs,y_hn = self.encoder(ys_packed)


    #     #print (x_hn.size(),y_hn.size())
    #     #print (xi.size(),ysi.size())
    #     x_hn = x_hn[xi]
    #     ys_hn = y_hn[ysi] # (batch_size*5, 2*hidden_dim) --> ( batch_size, 5, 2*hidden_dim)
    #     #print (x_hn.size(),ys_hn.size())

    #     #print (x_hn.size(),y_hn.size())
    #     # hs is PackedSequence, have no size, mean...
    #     #print (x_hs)
    #     x_hs,x_lens = pad_packed_sequence(x_hs,batch_first=True)
    #     x_hs,x_lens = x_hs[xi],x_lens[xi]
    #     y_hs,y_lens = pad_packed_sequence(y_hs,batch_first=True)
    #     ys_hs,ys_lens = y_hs[ysi],y_lens[ysi]
    #     #print (x_hs,x_lens) #x_hs.size = batch_size , max_len, hidden_dim_all
    #     #print (ys_lens)

    #     def getNumpyMask(hs_shape,lens):
    #         batch_size = hs_shape[:-2]
    #         max_len = hs_shape[-2]
    #         s = np.arange(0,max_len).reshape(1,-1)[np.zeros(batch_size,dtype=int)]
    #         mask_idx = s >= lens[:,None] if len(lens.shape) == 1 else s >= lens[:,:,None]
    #         s[:] = 0
    #         s[mask_idx] = -1e6
    #         return s

    #     x_hs_shape = np.array(x_hs.size())
    #     #print (x_hs_shape)
    #     x_np_lens = self.toNumpyArr(x_lens)
    #     #print (x_np_lens)
    #     mask_x = getNumpyMask(x_hs_shape,x_np_lens)
    #     #print (mask_x.shape)        
    #     ys_hs_shape = np.array(ys_hs.size())
    #     #print (ys_hs_shape)
    #     ys_np_lens = self.toNumpyArr(ys_lens)
    #     #print (ys_np_lens)
    #     mask_ys = getNumpyMask(ys_hs_shape,ys_np_lens)
    #     #print (mask_ys.shape)
    #     mask = mask_x[:,None,:,None] + mask_ys[:,:,None,:]
    #     #print (mask.shape)

    #     scores = torch.matmul(x_hs[:,None,:,:],ys_hs.transpose(-2, -1))
    #     #print (scores.size())
    #     scores = scores + torch.cuda.FloatTensor(mask)
    #     #print (scores.size())

    #     xs_att_ys = F.softmax(scores,dim=-1)
    #     ys_att_xs = F.softmax(scores,dim=-2)
    #     #print(xs_att_ys[0,0,0])
    #     #print(ys_att_xs[0,0,:,0])
    #     mir_xs_hs = ys_hs[:,:,None,:,:] * xs_att_ys[:,:,:,:,None]
    #     mir_xs_hs = torch.sum(mir_xs_hs,dim=-2)
    #     mir_ys_hs = x_hs[:,None,:,None,:] * ys_att_xs[:,:,:,:,None]
    #     mir_ys_hs = torch.sum(mir_ys_hs,dim=-3)

    #     #x_hn = x_hn.view(x_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
    #     #y_hn = y_hn.view(y_hn.size(0),-1)
    #     #x_hn = torch.sigmoid(self.prjLinear(x_hn))

    #     # scores = x_hn[:,None,:] * ys_hn
    #     # scores = scores.mean(-1) # batch_size x 5
    #     # scores = F.log_softmax(scores,dim = -1)
    #     #print (scores.size(),right.size())

    #     #dif_xs_hs = mir_xs_hs - x_hs[:,None,:]
    #     dot_xs_hs = mir_xs_hs * x_hs[:,None,:]
    #     #dif_ys_hs = mir_ys_hs - ys_hs
    #     dot_ys_hs = mir_ys_hs * ys_hs
    #     xs_hs = x_hs[:,None,:,:] + torch.cuda.FloatTensor(np.zeros(mir_xs_hs.size()))
    #     m_xs_hs = torch.cat((xs_hs,mir_xs_hs,dot_xs_hs),-1) #,dif_xs_hs
    #     m_ys_hs = torch.cat((ys_hs,mir_ys_hs,dot_ys_hs),-1) #,dif_ys_hs       

    #     #print (x_lens.float().cuda())
    #     #print (m_xs_hs.size(),m_ys_hs.size())
    #     #print(mask_x)
    #     mask_x = torch.exp(torch.cuda.FloatTensor(mask_x))
    #     mask_ys = torch.exp(torch.cuda.FloatTensor(mask_ys))
    #     #print(ys_lens)
    #     #print(mask_x)
    #     #print(ys_hs.mean,ys_hs.sum(-2) / ys_lens.float().cuda()[:,:,None])
    #     #print(mir_xs_hs)
    #     m_xs_hs = m_xs_hs * mask_x[:,None,:,None]
    #     m_ys_hs = m_ys_hs * mask_ys[:,:,:,None]
    #     #print (m_xs_hs.size(),m_ys_hs.size())
    #     #print (m_xs_hs.size(),m_ys_hs.size())
    #     #print (xs_hs[0,0,-1],mir_xs_hs[0,0,-1],dif_xs_hs[0,0,-1],dot_xs_hs[0,0,-1])
    #     # print ((xs_hs*mask_x[:,None,:,None])[0,0,-1],
    #     #         (mir_xs_hs*mask_x[:,None,:,None])[0,0,-1],
    #     #         (dif_xs_hs*mask_x[:,None,:,None])[0,0,-1],
    #     #         (dot_xs_hs*mask_x[:,None,:,None])[0,0,-1])
        

    #     mean_m_xs_hs = torch.sum(m_xs_hs,dim=-2) / x_lens.float().cuda()[:,None,None]
    #     mean_m_ys_hs = torch.sum(m_ys_hs,dim=-2) / ys_lens.float().cuda()[:,:,None] # batch_size,5,hidden_dim_all*3
    #     mean_x_hs = x_hs.sum(-2) / x_lens.float().cuda()[:,None]
    #     mean_ys_hs = ys_hs.sum(-2) / ys_lens.float().cuda()[:,:,None]
    #     mean_xs_hs = mean_x_hs[:,None,:] + torch.cuda.FloatTensor(np.zeros(mean_ys_hs.size()))
    #     xs_pr = torch.cat((mean_xs_hs,mean_m_xs_hs),-1)
    #     ys_pr = torch.cat((mean_ys_hs,mean_m_ys_hs),-1)
    #     xs_pr = self.prjLinear(xs_pr)
    #     ys_pr = self.prjLinear(ys_pr)
    #     scores = F.log_softmax((xs_pr*ys_pr).mean(-1),-1)

    #     if right is not None:
    #         if polar:
    #             nidx = (scores.data < np.log(0.2)).type_as(scores)
    #             #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
    #             #scores = scores*(negs*(-2)+1)[:,None]
    #             scores = scores*(nidx*(-2)+1)
    #         return self.lf(scores,right)
    #     else:
    #         if polar:
    #             #nidx = scores.data < np.log(0.2)
    #             #scores[nidx] = 1/scores[nidx]
    #             nidx = (scores.data < np.log(0.2)).type_as(scores)
    #             negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
    #             scores = scores*(negs*(-2)+1)[:,None]
    #         return scores

class stc_matching(nn.Module):
    def __init__(self,**option):
        super(stc_matching, self).__init__()
        self.svsize = option["vocSize"]
        self.wordDim = option["embdim"]
        self.hiddenDim = option["hidden"]
        self.outDim = option["outhid"]

        self.encoder = rnnEncoder(self.svsize, self.wordDim, self.hiddenDim, bidirc=option['bidirc'])
        self.hiddenDimAll = self.hiddenDim * (int(option['bidirc']+1))
        #self.prjLinear = nn.Linear(self.hiddenDimAll,self.hiddenDimAll)
        self.prjLinear = nn.Linear(self.hiddenDimAll*4,self.outDim)
        #self.prjcLinear = nn.Linear(hdim,hhdim)

        # optimizer and training        
        self.lf = nn.NLLLoss()
        self.alpha = option["alpha"]
        #self.optimizer = optim.Adam(self.parameters(), lr=option["alpha"])#, betas=(0.9, 0.999) )
        #self.optimizer = optim.Adam ([{'params': self.bertModel.parameters(), 'lr':0.00002},
        #                              {'params': self.prjLinear.parameters()},
        #                              {'params': self.prjcLinear.parameters()}] , lr=0.001 ) #(self.parameters(), lr=0.00002) #, betas=(0.9, 0.999) )
        #self.optimizer = BertAdam(self.parameters(),
                                     # lr=0.00005, # 0.000005
                                     # warmup=0.1,
                                     # t_total=total_step)
        #self.optimizer.zero_grad()

        # select gpu/cpu mode for model and dataType
        d = option["device"].lower().replace('gpu','cuda')
        self.inited = False 
        self.use_cuda = False
        self.LongTensor = torch.LongTensor
        self.device = torch.device(d)
        if "cuda" in d or "gpu" in d:
            self.use_cuda = True

    def init(self):
        if self.inited:
            return
        self.optimizer = optim.Adam(self.parameters(), lr=self.alpha)
        self.optimizer.zero_grad()
        if torch.cuda.is_available() and self.use_cuda:
            sys.stdout.write("Using cuda~ on device " + str(self.device) + "\n")
            # model into gpu
            self.to(self.device)
            # data type for gpu
            self.LongTensor = torch.cuda.LongTensor
            self.toDevice = lambda x: x.to(self.device) #x.cuda()
        else:
            self.toDevice = lambda x: x
        self.inited = True
        def toNumpyArr(var):
            return var.data.cpu().numpy()
        self.toNumpyArr = toNumpyArr
        return

    # def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
    #     # assert( len(stcX) * 5 == len(stcYs) ) # the batch_size
    #     # if right is not None:
    #     #     assert( len(stcX) == len(right) )
    #     # answer_num = len(stcYs[0])

    #     x_hs,x_hn = self.encoder(x_packed)
    #     y_hs,y_hn = self.encoder(ys_packed)

    #     x_hn = x_hn.view(x_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
    #     y_hn = y_hn.view(y_hn.size(0),-1)
    #     x_hn = torch.sigmoid(self.prjLinear(x_hn))

    #     #print (x_hn.size(),y_hn.size())
    #     #print (xi.size(),ysi.size())
    #     x_hn = x_hn[xi]
    #     ys_hn = y_hn[ysi] # (batch_size*5, 2*hidden_dim) --> ( batch_size, 5, 2*hidden_dim)
    #     #print (x_hn.size(),ys_hn.size())

    #     scores = x_hn[:,None,:] * ys_hn
    #     scores = scores.mean(-1) # batch_size x 5
    #     scores = F.log_softmax(scores,dim = -1)
    #     #print (scores.size(),right.size())

    #     if right is not None:
    #         if polar:
    #             nidx = (scores.data < np.log(0.2)).type_as(scores)
    #             #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
    #             #scores = scores*(negs*(-2)+1)[:,None]
    #             scores = scores*(nidx*(-2)+1)
    #         return self.lf(scores,right)
    #     else:
    #         if polar:
    #             #nidx = scores.data < np.log(0.2)
    #             #scores[nidx] = 1/scores[nidx]
    #             nidx = (scores.data < np.log(0.2)).type_as(scores)
    #             negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
    #             scores = scores*(negs*(-2)+1)[:,None]
    #         return scores

    def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
        # assert( len(stcX) * 5 == len(stcYs) ) # the batch_size
        # if right is not None:
        #     assert( len(stcX) == len(right) )
        # answer_num = len(stcYs[0])

        x_hs,x_hn = self.encoder(x_packed)
        y_hs,y_hn = self.encoder(ys_packed)


        #print (x_hn.size(),y_hn.size())
        #print (xi.size(),ysi.size())
        x_hn = x_hn[xi]
        ys_hn = y_hn[ysi] # (batch_size*5, 2*hidden_dim) --> ( batch_size, 5, 2*hidden_dim)
        #print (x_hn.size(),ys_hn.size())

        #print (x_hn.size(),y_hn.size())
        # hs is PackedSequence, have no size, mean...
        #print (x_hs)
        x_hs,x_lens = pad_packed_sequence(x_hs,batch_first=True)
        x_hs,x_lens = x_hs[xi],x_lens[xi]
        y_hs,y_lens = pad_packed_sequence(y_hs,batch_first=True)
        ys_hs,ys_lens = y_hs[ysi],y_lens[ysi]
        #print (x_hs,x_lens) #x_hs.size = batch_size , max_len, hidden_dim_all
        #print (ys_lens)

        def getNumpyMask(hs_shape,lens):
            batch_size = hs_shape[:-2]
            max_len = hs_shape[-2]
            s = np.arange(0,max_len).reshape(1,-1)[np.zeros(batch_size,dtype=int)]
            mask_idx = s >= lens[:,None] if len(lens.shape) == 1 else s >= lens[:,:,None]
            s[:] = 0
            s[mask_idx] = -1e6
            return s

        x_hs_shape = np.array(x_hs.size())
        #print (x_hs_shape)
        x_np_lens = self.toNumpyArr(x_lens)
        #print (x_np_lens)
        mask_x = getNumpyMask(x_hs_shape,x_np_lens)
        #print (mask_x.shape)        
        ys_hs_shape = np.array(ys_hs.size())
        #print (ys_hs_shape)
        ys_np_lens = self.toNumpyArr(ys_lens)
        #print (ys_np_lens)
        mask_ys = getNumpyMask(ys_hs_shape,ys_np_lens)
        #print (mask_ys.shape)
        mask = mask_x[:,None,:,None] + mask_ys[:,:,None,:]
        #print (mask.shape)

        scores = torch.matmul(x_hs[:,None,:,:],ys_hs.transpose(-2, -1))
        #print (scores.size())
        scores = scores + torch.cuda.FloatTensor(mask)
        #print (scores.size())

        xs_att_ys = F.softmax(scores,dim=-1)
        ys_att_xs = F.softmax(scores,dim=-2)
        #print(xs_att_ys[0,0,0])
        #print(ys_att_xs[0,0,:,0])
        mir_xs_hs = ys_hs[:,:,None,:,:] * xs_att_ys[:,:,:,:,None]
        mir_xs_hs = torch.sum(mir_xs_hs,dim=-2)
        mir_ys_hs = x_hs[:,None,:,None,:] * ys_att_xs[:,:,:,:,None]
        mir_ys_hs = torch.sum(mir_ys_hs,dim=-3)

        #x_hn = x_hn.view(x_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        #y_hn = y_hn.view(y_hn.size(0),-1)
        #x_hn = torch.sigmoid(self.prjLinear(x_hn))

        # scores = x_hn[:,None,:] * ys_hn
        # scores = scores.mean(-1) # batch_size x 5
        # scores = F.log_softmax(scores,dim = -1)
        #print (scores.size(),right.size())

        #dif_xs_hs = mir_xs_hs - x_hs[:,None,:]
        dot_xs_hs = mir_xs_hs * x_hs[:,None,:]
        #dif_ys_hs = mir_ys_hs - ys_hs
        dot_ys_hs = mir_ys_hs * ys_hs
        xs_hs = x_hs[:,None,:,:] + torch.cuda.FloatTensor(np.zeros(mir_xs_hs.size()))
        m_xs_hs = torch.cat((xs_hs,mir_xs_hs,dot_xs_hs),-1) #,dif_xs_hs
        m_ys_hs = torch.cat((ys_hs,mir_ys_hs,dot_ys_hs),-1) #,dif_ys_hs       

        #print (x_lens.float().cuda())
        #print (m_xs_hs.size(),m_ys_hs.size())
        #print(mask_x)
        mask_x = torch.exp(torch.cuda.FloatTensor(mask_x))
        mask_ys = torch.exp(torch.cuda.FloatTensor(mask_ys))
        #print(ys_lens)
        #print(mask_x)
        #print(ys_hs.mean,ys_hs.sum(-2) / ys_lens.float().cuda()[:,:,None])
        #print(mir_xs_hs)
        m_xs_hs = m_xs_hs * mask_x[:,None,:,None]
        m_ys_hs = m_ys_hs * mask_ys[:,:,:,None]
        #print (m_xs_hs.size(),m_ys_hs.size())
        #print (m_xs_hs.size(),m_ys_hs.size())
        #print (xs_hs[0,0,-1],mir_xs_hs[0,0,-1],dif_xs_hs[0,0,-1],dot_xs_hs[0,0,-1])
        # print ((xs_hs*mask_x[:,None,:,None])[0,0,-1],
        #         (mir_xs_hs*mask_x[:,None,:,None])[0,0,-1],
        #         (dif_xs_hs*mask_x[:,None,:,None])[0,0,-1],
        #         (dot_xs_hs*mask_x[:,None,:,None])[0,0,-1])
        

        mean_m_xs_hs = torch.sum(m_xs_hs,dim=-2) / x_lens.float().cuda()[:,None,None]
        mean_m_ys_hs = torch.sum(m_ys_hs,dim=-2) / ys_lens.float().cuda()[:,:,None] # batch_size,5,hidden_dim_all*3
        mean_x_hs = x_hs.sum(-2) / x_lens.float().cuda()[:,None]
        mean_ys_hs = ys_hs.sum(-2) / ys_lens.float().cuda()[:,:,None]
        mean_xs_hs = mean_x_hs[:,None,:] + torch.cuda.FloatTensor(np.zeros(mean_ys_hs.size()))
        xs_pr = torch.cat((mean_xs_hs,mean_m_xs_hs),-1)
        ys_pr = torch.cat((mean_ys_hs,mean_m_ys_hs),-1)
        xs_pr = self.prjLinear(xs_pr)
        ys_pr = self.prjLinear(ys_pr)
        scores = F.log_softmax((xs_pr*ys_pr).mean(-1),-1)

        if right is not None:
            if polar:
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                #scores = scores*(negs*(-2)+1)[:,None]
                scores = scores*(nidx*(-2)+1)
            return self.lf(scores,right)
        else:
            if polar:
                #nidx = scores.data < np.log(0.2)
                #scores[nidx] = 1/scores[nidx]
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                scores = scores*(negs*(-2)+1)[:,None]
            return scores

class stc_matching_att(nn.Module):
    def __init__(self,**option):
        super(stc_matching_att, self).__init__()
        self.svsize = option["vocSize"]
        self.wordDim = option["embdim"]
        self.hiddenDim = option["hidden"]
        self.outDim = option["outhid"]

        self.encoder = rnnEncoder(self.svsize, self.wordDim, self.hiddenDim, bidirc=option['bidirc'])
        self.hiddenDimAll = self.hiddenDim * (int(option['bidirc']+1))
        self.prjKeyLinear = nn.Linear(self.hiddenDimAll,self.hiddenDimAll)
        self.prjLinear = nn.Linear(self.hiddenDimAll*2,self.hiddenDimAll)
        #self.prjcLinear = nn.Linear(hdim,hhdim)

        # optimizer and training        
        self.lf = nn.NLLLoss()
        self.alpha = option["alpha"]

        # select gpu/cpu mode for model and dataType
        d = option["device"].lower().replace('gpu','cuda')
        self.inited = False 
        self.use_cuda = False
        self.LongTensor = torch.LongTensor
        self.device = torch.device(d)
        if "cuda" in d or "gpu" in d:
            self.use_cuda = True

    def init(self):
        if self.inited:
            return
        self.optimizer = optim.Adam(self.parameters(), lr=self.alpha)
        self.optimizer.zero_grad()
        if torch.cuda.is_available() and self.use_cuda:
            sys.stdout.write("Using cuda~ on device " + str(self.device) + "\n")
            # model into gpu
            self.to(self.device)
            # data type for gpu
            self.LongTensor = torch.cuda.LongTensor
            self.toDevice = lambda x: x.to(self.device) #x.cuda()
        else:
            self.toDevice = lambda x: x
        self.inited = True
        def toNumpyArr(var):
            return var.data.cpu().numpy()
        self.toNumpyArr = toNumpyArr
        return


    def forward(self,x_packed, ys_packed, xi, ysi, right = None, polar=False):
        x_hs,x_hn = self.encoder(x_packed)
        y_hs,y_hn = self.encoder(ys_packed)

        #print (x_hn.size(),y_hn.size())
        #print (xi.size(),ysi.size())        
        x_hn = x_hn.view(x_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        y_hn = y_hn.view(y_hn.size(0),-1)
        x_hn = x_hn[xi]
        ys_hn = y_hn[ysi] # (batch_size*5, 2*hidden_dim) --> ( batch_size, 5, 2*hidden_dim)
        #print (x_hn.size(),ys_hn.size())

        #print (x_hn.size(),y_hn.size())
        # hs is PackedSequence, have no size, mean...
        #print (x_hs)
        x_hs,x_lens = pad_packed_sequence(x_hs,batch_first=True)
        x_hs,x_lens = x_hs[xi],x_lens[xi]
        y_hs,y_lens = pad_packed_sequence(y_hs,batch_first=True)
        ys_hs,ys_lens = y_hs[ysi],y_lens[ysi]
        #print (x_hs,x_lens) #x_hs.size = batch_size , max_len, hidden_dim_all
        #print (ys_lens)

        def getNumpyMask(hs_shape,lens):
            batch_size = hs_shape[:-2]
            max_len = hs_shape[-2]
            s = np.arange(0,max_len).reshape(1,-1)[np.zeros(batch_size,dtype=int)]
            mask_idx = s >= lens[:,None] if len(lens.shape) == 1 else s >= lens[:,:,None]
            s[:] = 0
            s[mask_idx] = -1e6
            return s

        x_hs_shape = np.array(x_hs.size())
        #print (x_hs_shape)
        x_np_lens = self.toNumpyArr(x_lens)
        #print (x_np_lens)
        mask_x = getNumpyMask(x_hs_shape,x_np_lens)
        # mask_x.size() (batch_size, max_len_x)
        key_y = self.prjKeyLinear(ys_hn)

        scores = x_hs[:,None,:,:] * key_y[:,:,None,:]
        scores = torch.sum(scores,dim=-1) # batch_size,5,max_len_x
        #print (scores.size())
        scores = scores + torch.cuda.FloatTensor(mask_x)[:,None,:]
        #print (scores.size())

        ys_att_xs = F.softmax(scores,dim=-1)
        ctxs = x_hs[:,None,:,:] * ys_att_xs[:,:,:,None]
        ctxs = torch.sum(ctxs,dim=-2)

        xs_hn = x_hn[:,None,:] + torch.cuda.FloatTensor(np.zeros(ctxs.size()))
        xs_os = self.prjLinear(torch.cat((ctxs,xs_hn),-1))

        scores = F.log_softmax((xs_os*ys_hn).mean(-1),-1)

        if right is not None:
            if polar:
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                #negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                #scores = scores*(negs*(-2)+1)[:,None]
                scores = scores*(nidx*(-2)+1)
            return self.lf(scores,right)
        else:
            if polar:
                #nidx = scores.data < np.log(0.2)
                #scores[nidx] = 1/scores[nidx]
                nidx = (scores.data < np.log(0.2)).type_as(scores)
                negs = (torch.sum(nidx,-1) < 2.5).type_as(scores)
                scores = scores*(negs*(-2)+1)[:,None]
            return scores

    def get_similar(self,stc1_packed,stc2_packed, s1i, s2i):
        
        s1_hs,s1_hn = self.encoder(stc1_packed)
        s2_hs,s2_hn = self.encoder(stc2_packed)        

        s1_hn = s1_hn.view(s1_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        s2_hn = s2_hn.view(s2_hn.size(0),-1) # (batch_size, 2, hidden_dim) --> (batch_size, 2*hidden_dim)
        s1_hn = s1_hn[s1i]
        s2_hn = s2_hn[s2i]

        return self.toNumpyArr((s1_hn*s2_hn).mean(-1))



