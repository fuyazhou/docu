from __future__ import print_function

import os, sys, time
import random
import numpy as np
import json

import jieba
import pickle
import torch
from torch.nn.utils.rnn import pack_padded_sequence
from torch.utils.data import DataLoader
from match_func.stc_matching import tokenizer
from match_func.stc_matching import stc_matching, stc_matching_hn, stc_matching_hmean, stc_matching_att


def loadModel(modelname, device=None, alpha=None):
    pathname, filename = os.path.split(modelname)
    modelname = os.path.join(pathname, filename)
    if modelname.endswith('.pt'):
        modelname = modelname[:-3]
    if modelname.endswith('.pkl'):
        modelname = modelname[:-4]
    print(modelname + '.pkl/.pt')

    option = pickle.load(open(modelname + '.pkl', 'rb'))
    if device is not None:
        option['device'] = device
    if alpha is not None:
        option['alpha'] = alpha
    print(option)

    modelClass = eval(option["model"])
    print(modelClass)
    model = modelClass(**option)
    model.load_state_dict(torch.load(modelname + '.pt'))
    # for param_tensor in model.state_dict():
    #     pn,pm = param_tensor,model.state_dict()[param_tensor]
    #     print(pn,pm.device)
    #     if torch.is_tensor(pm):
    #         pm.to(model.device)
    #     print(pn,pm.device)
    # for para_name in model.state_dict():
    #     model.state_dict()[para_name].to(model.device)
    for param_tensor in model.state_dict():
        pn, pm = param_tensor, model.state_dict()[param_tensor]
        print(pn, "\t", pm.size(), "\t", type(pm), "\t", pm.device)  # torch.cuda.device_of(pm))
    return model


def pack_seqs(seqs, ttype=None):
    '''
    seqs = [[1,2,3],[1,2]]  -> packed_sequence
    '''
    ttype = ttype if ttype else torch.cuda.LongTensor
    lens = [len(t) for t in seqs]
    padded = ttype(np.zeros((len(seqs), max(lens))))
    for i, t in enumerate(seqs):
        end = lens[i]
        padded[i, :end] = ttype(t[:end])
    lens = torch.tensor(lens)
    # print (padded,lens)
    seq_packed = pack_padded_sequence(padded, lengths=lens, batch_first=True)
    return seq_packed


def pack_stcs(stcs1, stcs2):
    indices = np.argsort([len(s) for s in stcs1])[::-1]  # desc
    x_reind = np.argsort(indices)  # stcs1[indices][x_reind] = stcs1[range(len)]
    stcs1 = [stcs1[i] for i in indices]

    indices = np.argsort([len(t) for t in stcs2])[::-1]
    y_reind = np.argsort(indices)
    stcs2 = [stcs2[i] for i in indices]

    x_packed = pack_seqs(stcs1)
    y_packed = pack_seqs(stcs2)

    xi = torch.cuda.LongTensor(x_reind)
    yi = torch.cuda.LongTensor(y_reind)

    return x_packed, y_packed, xi, yi


def getParaCnt(moduleObj):
    k = 0
    for i in list(moduleObj.parameters()):
        l = 1
        for j in i.size():
            l *= j
        k = k + l
    return k


def printModule(moduleObj, indent=' |', name=''):
    s = str(moduleObj).strip().split('\n')[0].strip()
    if s.endswith('('):
        s = s[:s.rfind('(')]
        print(indent[:-2] + '-+' + s + '\t[' + name + ']\t#' + str(getParaCnt(moduleObj)))
        indent += ' |'
    else:
        print(indent[:-2] + '->' + s + '\t[' + name + ']\t#' + str(getParaCnt(moduleObj)))
        indent += ' -'
    for n, m in moduleObj.named_children():
        printModule(m, indent=indent, name=n)
    return


class match_class(object):
    """docstring for match_class"""

    def __init__(self, modelname, device):
        super(match_class, self).__init__()

        preModel = modelname
        option = {}
        if len(preModel) > 0:
            option_p = pickle.load(open(preModel + '.pkl', 'rb'))
            for k in ['model', 'vocab', 'eos', 'unk', 'embdim', 'hidden', 'outhid', 'bidirc']:
                option[k] = option_p[k]
        tker = tokenizer(vocabName=option['vocab'], eos=option["eos"], unk=option["unk"])
        option["vocSize"] = len(tker.vocList)
        option['device'] = None
        print(option)

        # build model
        if ':' in device:
            option['device'], did = device.split(':')
            os.environ["CUDA_VISIBLE_DEVICES"] = did

        model = loadModel(preModel, device=option['device'])
        model.init()

        printModule(model)
        sys.stdout.write('@ ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time())) + '\n')

        self.tker = tker
        self.model = model

    def match_score(self, stcs1, stcs2):
        stcs1 = [' '.join(list(jieba.cut(s))) for s in stcs1]
        stcs2 = [' '.join(list(jieba.cut(s))) for s in stcs2]

        stcs1 = [self.tker.convert_tokens_to_ids(s) for s in stcs1]
        stcs2 = [self.tker.convert_tokens_to_ids(s) for s in stcs2]

        stcs1, stcs2, s1i, s2i = pack_stcs(stcs1, stcs2)

        return self.model.get_similar(stcs1, stcs2, s1i, s2i)


if __name__ == "__main__":
    matcher = match_class('test.att', 'cuda:0')
    s1 = ['晚期产后出血术后应给予（  ）。'] * 5
    s2 = ['晚期产后出血术后应给予（  ）。', '晚期产后出血术后最需要（  ）。', '分娩24小时后', '子宫大量出血称', '分娩24小时后，在产褥期内发生的子宫大量出血称为（  ）。']
    scores = matcher.match_score(s1, s2)
    for s1, s2, s in zip(s1, s2, scores):
        print(s1, s2, s)
