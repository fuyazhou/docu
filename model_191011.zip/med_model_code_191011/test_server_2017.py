import bert_model
import retrieve
import json
from tqdm import tqdm

id2letter = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E'}
letter2id = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4}


def read_answers(path):
    ans = {}
    data = json.load(open(path, encoding='utf8'))
    for d in data:
        ans[d['qid']] = id2letter[d['answer']]
    return ans


def calculate_accuracy(true_ans, predicted):
    acc = 0
    for key in true_ans:
        if true_ans[key] in predicted[key]:
            acc += 1
    return acc / len(true_ans), acc


def find_max_in_five(a):
    if a[0] == max(a):
        return 0
    if a[1] == max(a):
        return 1
    if a[2] == max(a):
        return 2
    if a[3] == max(a):
        return 3
    return 4


def get_result(logits, ids):
    result = {}
    for i, id in enumerate(ids):
        label_pred = find_max_in_five(logits[i])
        if label_pred == 0:
            label_pred = 'A'
        elif label_pred == 1:
            label_pred = 'B'
        elif label_pred == 2:
            label_pred = 'C'
        elif label_pred == 3:
            label_pred = 'D'
        else:
            label_pred = 'E'
        result[id] = [label_pred]
    return result


ret_model = retrieve.model()
model_A1, model_A2, model_A3A4, model_B1 = (bert_model.Evaluation('bert', 'model/A1', ret_model),
                                            bert_model.Evaluation('bert', 'model/A2', ret_model),
                                            bert_model.Evaluation('bert', 'model/A3A4', ret_model),
                                            bert_model.Evaluation('bert', 'model/B1', ret_model))
outfile2017 = ''

devset_path = '../../passage/testset2017_A1.json'
logit_save = []
qid_list = []
for d in tqdm(json.load(open(devset_path))):
    qid_list.append(d['qid'])
    logit_save.append(model_A1.run(d['question'], d['candidates']))
result = get_result(logit_save, qid_list)
true_ans = read_answers(devset_path)
em_A1, em_num_A1 = calculate_accuracy(true_ans, result)
print('A1:', em_A1, em_num_A1)

for i, d in enumerate(json.load(open(devset_path))):
    outfile2017 += d['question']
    outfile2017 += '\t'
    outfile2017 += '\t'.join(d['candidates'])
    outfile2017 += '\t'
    outfile2017 += d['type']
    outfile2017 += '\t'
    outfile2017 += '2017'
    outfile2017 += '\t'
    outfile2017 += str(d['answer'])
    outfile2017 += '\t'
    outfile2017 += str(letter2id[result[d['qid']][0]])
    outfile2017 += '\t'
    outfile2017 += str(logit_save[i][letter2id[result[d['qid']][0]]])
    outfile2017 += '\n'

devset_path = '../../passage/testset2017_A2.json'
logit_save = []
qid_list = []
for d in tqdm(json.load(open(devset_path))):
    qid_list.append(d['qid'])
    logit_save.append(model_A2.run(d['question'], d['candidates']))
result = get_result(logit_save, qid_list)
true_ans = read_answers(devset_path)
em_A2, em_num_A2 = calculate_accuracy(true_ans, result)
print('A2:', em_A2, em_num_A2)

for i, d in enumerate(json.load(open(devset_path))):
    outfile2017 += d['question']
    outfile2017 += '\t'
    outfile2017 += '\t'.join(d['candidates'])
    outfile2017 += '\t'
    outfile2017 += d['type']
    outfile2017 += '\t'
    outfile2017 += '2017'
    outfile2017 += '\t'
    outfile2017 += str(d['answer'])
    outfile2017 += '\t'
    outfile2017 += str(letter2id[result[d['qid']][0]])
    outfile2017 += '\t'
    outfile2017 += str(logit_save[i][letter2id[result[d['qid']][0]]])
    outfile2017 += '\n'

devset_path = '../../passage/testset2017_A3A4.json'
logit_save = []
qid_list = []
for d in tqdm(json.load(open(devset_path))):
    qid_list.append(d['qid'])
    logit_save.append(model_A3A4.run(d['question'], d['candidates']))
result = get_result(logit_save, qid_list)
true_ans = read_answers(devset_path)
em_A3A4, em_num_A3A4 = calculate_accuracy(true_ans, result)
print('A3A4:', em_A3A4, em_num_A3A4)

for i, d in enumerate(json.load(open(devset_path))):
    outfile2017 += d['question']
    outfile2017 += '\t'
    outfile2017 += '\t'.join(d['candidates'])
    outfile2017 += '\t'
    outfile2017 += d['type']
    outfile2017 += '\t'
    outfile2017 += '2017'
    outfile2017 += '\t'
    outfile2017 += str(d['answer'])
    outfile2017 += '\t'
    outfile2017 += str(letter2id[result[d['qid']][0]])
    outfile2017 += '\t'
    outfile2017 += str(logit_save[i][letter2id[result[d['qid']][0]]])
    outfile2017 += '\n'

devset_path = '../../passage/testset2017_B1.json'
logit_save = []
qid_list = []
for d in tqdm(json.load(open(devset_path))):
    qid_list.append(d['qid'])
    logit_save.append(model_B1.run(d['question'], d['candidates']))
result = get_result(logit_save, qid_list)
true_ans = read_answers(devset_path)
em_B1, em_num_B1 = calculate_accuracy(true_ans, result)
print('B1:', em_B1, em_num_B1)

for i, d in enumerate(json.load(open(devset_path))):
    outfile2017 += d['question']
    outfile2017 += '\t'
    outfile2017 += '\t'.join(d['candidates'])
    outfile2017 += '\t'
    outfile2017 += d['type']
    outfile2017 += '\t'
    outfile2017 += '2017'
    outfile2017 += '\t'
    outfile2017 += str(d['answer'])
    outfile2017 += '\t'
    outfile2017 += str(letter2id[result[d['qid']][0]])
    outfile2017 += '\t'
    outfile2017 += str(logit_save[i][letter2id[result[d['qid']][0]]])
    outfile2017 += '\n'

with open('bert2017.txt', 'w', encoding='utf8') as f:
    f.write(outfile2017)

print('2017')
print('total:', em_num_A1 + em_num_A2 + em_num_A3A4 + em_num_B1)
print('A1:', em_A1, em_num_A1)
print('A2:', em_A2, em_num_A2)
print('A3A4:', em_A3A4, em_num_A3A4)
print('B1:', em_B1, em_num_B1)

# outfile2018 = ''
#
# devset_path = '../../passage/testset2018_A1.json'
# logit_save = []
# qid_list = []
# for d in tqdm(json.load(open(devset_path))):
#     qid_list.append(d['qid'])
#     logit_save.append(model_A1.run(d['question'], d['candidates']))
# result = get_result(logit_save, qid_list)
# true_ans = read_answers(devset_path)
# em_A1, em_num_A1 = calculate_accuracy(true_ans, result)
# print('A1:', em_A1, em_num_A1)

# for i, d in enumerate(json.load(open(devset_path))):
#     outfile2018 += d['question']
#     outfile2018 += '\t'
#     outfile2018 += '\t'.join(d['candidates'])
#     outfile2018 += '\t'
#     outfile2018 += d['type']
#     outfile2018 += '\t'
#     outfile2018 += '2018'
#     outfile2018 += '\t'
#     outfile2018 += str(d['answer'])
#     outfile2018 += '\t'
#     outfile2018 += str(letter2id[result[d['qid']][0]])
#     outfile2018 += '\t'
#     outfile2018 += str(logit_save[i][letter2id[result[d['qid']][0]]])
#     outfile2018 += '\n'

# devset_path = '../../passage/testset2018_A2.json'
# # logit_save = []
# # qid_list = []
# # for d in tqdm(json.load(open(devset_path))):
# #     qid_list.append(d['qid'])
# #     logit_save.append(model_A2.run(d['question'], d['candidates']))
# # result = get_result(logit_save, qid_list)
# # true_ans = read_answers(devset_path)
# # em_A2, em_num_A2 = calculate_accuracy(true_ans, result)
# # print('A2:', em_A2, em_num_A2)

# for i, d in enumerate(json.load(open(devset_path))):
#     outfile2018 += d['question']
#     outfile2018 += '\t'
#     outfile2018 += '\t'.join(d['candidates'])
#     outfile2018 += '\t'
#     outfile2018 += d['type']
#     outfile2018 += '\t'
#     outfile2018 += '2018'
#     outfile2018 += '\t'
#     outfile2018 += str(d['answer'])
#     outfile2018 += '\t'
#     outfile2018 += str(letter2id[result[d['qid']][0]])
#     outfile2018 += '\t'
#     outfile2018 += str(logit_save[i][letter2id[result[d['qid']][0]]])
#     outfile2018 += '\n'

# devset_path = '../../passage/testset2018_A3A4.json'
# logit_save = []
# qid_list = []
# for d in tqdm(json.load(open(devset_path))):
#     qid_list.append(d['qid'])
#     logit_save.append(model_A3A4.run(d['question'], d['candidates']))
# result = get_result(logit_save, qid_list)
# true_ans = read_answers(devset_path)
# em_A3A4, em_num_A3A4 = calculate_accuracy(true_ans, result)
# print('A3A4:', em_A3A4, em_num_A3A4)

# for i, d in enumerate(json.load(open(devset_path))):
#     outfile2018 += d['question']
#     outfile2018 += '\t'
#     outfile2018 += '\t'.join(d['candidates'])
#     outfile2018 += '\t'
#     outfile2018 += d['type']
#     outfile2018 += '\t'
#     outfile2018 += '2018'
#     outfile2018 += '\t'
#     outfile2018 += str(d['answer'])
#     outfile2018 += '\t'
#     outfile2018 += str(letter2id[result[d['qid']][0]])
#     outfile2018 += '\t'
#     outfile2018 += str(logit_save[i][letter2id[result[d['qid']][0]]])
#     outfile2018 += '\n'

# devset_path = '../../passage/testset2018_B1.json'
# logit_save = []
# qid_list = []
# for d in tqdm(json.load(open(devset_path))):
#     qid_list.append(d['qid'])
#     logit_save.append(model_B1.run(d['question'], d['candidates']))
# result = get_result(logit_save, qid_list)
# true_ans = read_answers(devset_path)
# em_B1, em_num_B1 = calculate_accuracy(true_ans, result)
# print('B1:', em_B1, em_num_B1)

# for i, d in enumerate(json.load(open(devset_path))):
#     outfile2018 += d['question']
#     outfile2018 += '\t'
#     outfile2018 += '\t'.join(d['candidates'])
#     outfile2018 += '\t'
#     outfile2018 += d['type']
#     outfile2018 += '\t'
#     outfile2018 += '2018'
#     outfile2018 += '\t'
#     outfile2018 += str(d['answer'])
#     outfile2018 += '\t'
#     outfile2018 += str(letter2id[result[d['qid']][0]])
#     outfile2018 += '\t'
#     outfile2018 += str(logit_save[i][letter2id[result[d['qid']][0]]])
#     outfile2018 += '\n'

# with open('bert2018.txt', 'w', encoding='utf8') as f:
#     f.write(outfile2018)
#
# print('2018')
# print('total:', em_num_A1 + em_num_A2 + em_num_A3A4 + em_num_B1)
# print('A1:', em_A1, em_num_A1)
# print('A2:', em_A2, em_num_A2)
# print('A3A4:', em_A3A4, em_num_A3A4)
# print('B1:', em_B1, em_num_B1)
