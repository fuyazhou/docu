# coding: utf-8

import tensorflow as tf
import bert.modeling as modeling
import numpy as np
import bert.tokenization as tokenization
import retrieve
from tqdm import tqdm, trange
import json
import 医学指标

INF = 1e30


def mask_for_softmax(val, mask):
    return -INF * (1 - tf.cast(mask, tf.float32)) + val


class Model(object):
    def __init__(self, bert_path, config, is_training):
        print("Building model...")
        if is_training:
            self.dropout_rate = tf.placeholder(tf.float32)
            self.dropout_rate_num = 0.5
        else:
            self.dropout_rate = 0.0
        self.lr = 0.00001
        self.batch_size = 2
        if not is_training:
            self.batch_size *= 2
        self.num_epochs = 25

        self.text_length_max = config["ans_length"]
        self.question_length_max = config["question_length"]
        self.is_training = is_training

        self.bert_config_file = bert_path + '/bert_config.json'
        self.init_checkpoint = bert_path + '/bert_model.ckpt'

        print("Max text length:", self.text_length_max)
        print("Max question length:", self.question_length_max)

        self._placeholders()
        self.forward = self._forward()
        if self.is_training:
            self.loss = self._loss()
            self.train = self._train()

    def _placeholders(self):
        self.p_input = tf.placeholder(tf.int32, (None, 5, self.question_length_max + self.text_length_max + 4), "input")
        self.p_input_mask = tf.placeholder(tf.int32, (None, 5, self.question_length_max + self.text_length_max + 4),
                                           "input_mask")
        self.p_input_seg = tf.placeholder(tf.int32, (None, 5, self.question_length_max + self.text_length_max + 4),
                                          "input_seg")
        self.p_input_neg = tf.placeholder(tf.int32, (None,), "input_neg")
        if self.is_training:
            self.p_label = tf.placeholder(tf.int32, (None,), "label")

            dataset_tf = tf.data.Dataset.from_tensor_slices((self.p_input,
                                                             self.p_input_mask,
                                                             self.p_input_seg,
                                                             self.p_label))

            dataset_tf = dataset_tf.batch(self.batch_size)

            self.iter = dataset_tf.make_initializable_iterator()
            self.input, \
            self.input_mask, \
            self.input_seg, \
            self.label = self.iter.get_next()

        else:
            dataset_tf = tf.data.Dataset.from_tensor_slices((self.p_input,
                                                             self.p_input_mask,
                                                             self.p_input_seg))

            dataset_tf = dataset_tf.batch(self.batch_size)

            self.iter = dataset_tf.make_initializable_iterator()
            self.input, \
            self.input_mask, \
            self.input_seg = self.iter.get_next()

    def _forward(self):
        bert_config = modeling.BertConfig.from_json_file(self.bert_config_file)

        input_reshape = tf.reshape(self.input, (-1, self.input.shape[-1].value))
        input_mask_reshape = tf.reshape(self.input_mask, (-1, self.input.shape[-1].value))
        input_seg_reshape = tf.reshape(self.input_seg, (-1, self.input.shape[-1].value))

        model = modeling.BertModel(bert_config, False, input_reshape, input_mask_reshape, input_seg_reshape)

        input_e = model.get_sequence_output()

        input_e = input_e[:, 0, :]

        input_e = tf.reshape(input_e, (-1, 5, bert_config.hidden_size))
        if self.is_training:
            input_e = tf.nn.dropout(input_e, 1 - self.dropout_rate)
        logit = tf.layers.dense(input_e, 1024, tf.nn.tanh, kernel_initializer=tf.contrib.layers.xavier_initializer(),
                                name='ff1')
        if self.is_training:
            logit = tf.nn.dropout(logit, 1 - self.dropout_rate)
        logit = tf.layers.dense(logit, 1, kernel_initializer=tf.contrib.layers.xavier_initializer(), name='ff3')

        return tf.squeeze(logit)

    def _loss(self):
        loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=self.label, logits=self.forward)
        loss = tf.reduce_mean(loss)

        return loss

    def _train(self):
        self.lr_d = tf.placeholder(tf.float32)
        optimizer = tf.train.AdamOptimizer(learning_rate=self.lr_d)
        return optimizer.minimize(self.loss)


class Evaluation(object):
    def __init__(self, bert_path, model_path, ret_model=None):
        self.ret_model = ret_model if ret_model is not None else retrieve.model()
        self.ans_length = 25
        self.question_length = 150
        self.passage_length = 332

        self.set_name = 'B1'
        if 'A1' in model_path:
            self.set_name = 'A1'
        if 'A2' in model_path:
            self.set_name = 'A2'
        if 'A3A4' in model_path:
            self.set_name = 'A3A4'

        if self.set_name == 'A3A4':
            self.question_length = 190
            self.passage_length = 292
        if self.set_name == 'A1' or self.set_name == 'B1':
            self.question_length = 50
            self.passage_length = 432

        self.tokenizer = tokenization.FullTokenizer(vocab_file=bert_path + '/vocab.txt', do_lower_case=True)

        self.graph = tf.Graph()
        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True
        self.sess = tf.Session(graph=self.graph, config=config)
        with self.graph.as_default():
            config = {"ans_length": self.ans_length,
                      "question_length": self.question_length + self.passage_length}
            self.model = Model(bert_path, config, False)
            saver = tf.train.Saver(tf.global_variables(), max_to_keep=1)

        checkpoint_file = tf.train.latest_checkpoint(model_path)
        saver.restore(self.sess, checkpoint_file)
        print('model loaded at ' + model_path)

    def run(self, question, candidates):
        # if self.set_name == 'A2' or self.set_name == 'A3A4':
        #     question = 医学指标.process_line(question)
        passage_ans, text_ans = self.ret_model.run(question, candidates)
        input_id, input_mask, input_seg = self.load_dataset(question, candidates, passage_ans, text_ans)
        feed_dict = {self.model.p_input: np.expand_dims(input_id, 0),
                     self.model.p_input_mask: np.expand_dims(input_mask, 0),
                     self.model.p_input_seg: np.expand_dims(input_seg, 0)}
        with self.graph.as_default():
            self.sess.run(self.model.iter.initializer, feed_dict=feed_dict)
            logit = self.sess.run(self.model.forward)
        logit = np.reshape(logit, (-1,))
        prob = np.exp(logit) / np.sum(np.exp(logit), keepdims=True)
        return prob

    def _truncate_seq_pair(self, tokens_a, tokens_b, max_length):
        while True:
            total_length = len(tokens_a) + len(tokens_b)
            if total_length <= max_length:
                break
            if len(tokens_a) > len(tokens_b):
                tokens_a.pop()
            else:
                tokens_b.pop()

    def convert_single_example(self, max_seq_length, tokenizer, text_a, text_b=None):
        if text_a.find('[SEP]') != -1:
            text_a_a, text_a_b = text_a.split('[SEP]')
            text_a_a = tokenizer.tokenize(text_a_a)
            text_a_b = tokenizer.tokenize(text_a_b)
            tokens_a = text_a_a + ['[SEP]'] + text_a_b
        else:
            tokens_a = tokenizer.tokenize(text_a)
        tokens_b = None
        if text_b:
            tokens_b = tokenizer.tokenize(text_b)
        if tokens_b:
            self._truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
        else:
            if len(tokens_a) > max_seq_length - 2:
                tokens_a = tokens_a[0:(max_seq_length - 2)]

        tokens = []
        segment_ids = []
        tokens.append("[CLS]")
        segment_ids.append(0)
        for token in tokens_a:
            tokens.append(token)
            segment_ids.append(0)
        tokens.append("[SEP]")
        segment_ids.append(0)
        if tokens_b:
            for token in tokens_b:
                tokens.append(token)
                segment_ids.append(1)
            tokens.append("[SEP]")
            segment_ids.append(1)
        input_ids = tokenizer.convert_tokens_to_ids(tokens)
        input_mask = [1] * len(input_ids)
        while len(input_ids) < max_seq_length:
            input_ids.append(0)
            input_mask.append(0)
            segment_ids.append(0)
        assert len(input_ids) == max_seq_length
        assert len(input_mask) == max_seq_length
        assert len(segment_ids) == max_seq_length
        return input_ids, input_mask, segment_ids

    def load_dataset(self, question, full_ans, passage, tb):
        def cut_length(sentence, length):
            return sentence[:length]

        def cut_length_from_back(sentence, length):
            return sentence[-length:]

        input_id = []
        input_mask = []
        input_seg = []
        for index_ans, ans in enumerate(full_ans):
            passage_concat = cut_length('。'.join(passage[index_ans]), int(self.passage_length / 2))
            tb_length = int(self.passage_length / 2) if len(passage_concat) == int(self.passage_length / 2) \
                else self.passage_length - len(passage_concat)
            tb_concat = cut_length(' '.join(tb[index_ans]), tb_length)
            input_ids_s, input_mask_s, segment_ids_s = self.convert_single_example(
                self.passage_length + self.question_length + self.ans_length + 4,
                self.tokenizer,
                cut_length(passage_concat + tb_concat, self.passage_length)
                + '[SEP]'
                +
                cut_length_from_back(str(question), self.question_length)
                ,
                cut_length(str(ans), self.ans_length))
            input_id.append(np.expand_dims(input_ids_s, 0))
            input_mask.append(np.expand_dims(input_mask_s, 0))
            input_seg.append(np.expand_dims(segment_ids_s, 0))

        input_id = np.vstack(input_id)
        input_mask = np.vstack(input_mask)
        input_seg = np.vstack(input_seg)

        return input_id, input_mask, input_seg


class Train(object):
    def __init__(self, bert_path, model_path, train_data_path, dev_data_path):
        self.ret_model = retrieve.model()
        self.ans_length = 25
        self.question_length = 150
        self.passage_length = 332
        self.tokenizer = tokenization.FullTokenizer(vocab_file=bert_path + '/vocab.txt', do_lower_case=True)

        config = {"ans_length": self.ans_length,
                  "question_length": self.question_length + self.passage_length}
        self.model = Model(bert_path, config, True)
        saver = tf.train.Saver(tf.global_variables(), max_to_keep=1)
        self.sess = tf.Session()
        tvars = tf.trainable_variables()
        (assignment_map, initialized_variable_names) = modeling.get_assignment_map_from_checkpoint(tvars,
                                                                                                   self.model.init_checkpoint)
        tf.train.init_from_checkpoint(self.model.init_checkpoint, assignment_map)

        init_op = tf.global_variables_initializer()
        self.sess.run(init_op)

        set_train = self.load_dataset(train_data_path, self.tokenizer, self.ans_length, self.question_length,
                                      self.passage_length)
        set_dev_list = []
        for name in dev_data_path:
            set_dev = self.load_dataset(name, self.tokenizer, self.ans_length, self.question_length,
                                        self.passage_length)
            set_dev_list.append(set_dev)

        max_score = 0.0

        for i in range(self.model.num_epochs):
            print('\n[epoch number:', i, "]")
            print('Training')

            loss_mean = 0
            set_input, set_input_mask, set_input_seg, set_label, id_orig = set_train
            feed_dict = {self.model.p_input: set_input,
                         self.model.p_input_mask: set_input_mask,
                         self.model.p_input_seg: set_input_seg,
                         self.model.p_label: set_label}
            self.sess.run(self.model.iter.initializer, feed_dict=feed_dict)
            data_size = len(id_orig)
            num_batches_per_epoch = int((data_size - 1) / self.model.batch_size) + 1
            t = trange(num_batches_per_epoch, ncols=70)
            lr = self.model.lr - (self.model.lr - 0) / self.model.num_epochs * i
            # lr = model.lr

            for num_batch in t:
                _, loss_batch = self.sess.run([self.model.train, self.model.loss],
                                              feed_dict={self.model.lr_d: lr,
                                                         self.model.dropout_rate: self.model.dropout_rate_num})
                t.set_postfix({'loss_batch': loss_batch})
                loss_mean += loss_batch

            loss_mean = loss_mean / num_batches_per_epoch
            print('[train loss:', loss_mean, "]")

            print('Testing on dev set...')

            em_mean = []
            for set_index, name in enumerate(dev_data_path):
                print('dev set name:', name)
                set_input, set_input_mask, set_input_seg, set_label, id_orig = set_dev_list[set_index]
                feed_dict = {self.model.p_input: set_input,
                             self.model.p_input_mask: set_input_mask,
                             self.model.p_input_seg: set_input_seg,
                             self.model.p_label: np.zeros([len(id_orig), ])}

                self.sess.run(self.model.iter.initializer, feed_dict=feed_dict)
                data_size = len(id_orig)
                num_batches_per_epoch = int((data_size - 1) / self.model.batch_size) + 1
                logit_save = []
                logit_log = {}
                for num_batch_dev in trange(num_batches_per_epoch, ncols=60):
                    logit = self.sess.run(self.model.forward, feed_dict={self.model.dropout_rate: 0.0})
                    if len(logit.shape) < 2:
                        logit = [logit]
                    logit_save.append(logit)

                logit_save = np.concatenate(logit_save)
                for qid_i, qid in enumerate(id_orig):
                    logit_log[qid] = logit_save[qid_i]

                result = self.get_result(logit_save, id_orig)
                true_ans = self.read_answers(name)
                em, em_num = self.calculate_accuracy(true_ans, result)
                print('dev set accuracy:', em)
                print(em_num, 'of', len(true_ans), 'are correct')
                em_mean.append(em)

                set_input, set_input_mask, set_input_seg, set_label, id_orig = set_dev_list[set_index]
                feed_dict = {self.model.p_input: set_input,
                             self.model.p_input_mask: set_input_mask,
                             self.model.p_input_seg: set_input_seg,
                             self.model.p_label: set_label}

                self.sess.run(self.model.iter.initializer, feed_dict=feed_dict)
                data_size = len(id_orig)
                num_batches_per_epoch = int((data_size - 1) / self.model.batch_size) + 1
                loss_mean_dev = 0
                t = trange(num_batches_per_epoch, ncols=70)
                for num_batch_dev in t:
                    loss_batch = self.sess.run(self.model.loss,
                                               feed_dict={self.model.dropout_rate: self.model.dropout_rate_num})
                    t.set_postfix({'loss_batch': loss_batch})
                    loss_mean_dev += loss_batch
                loss_mean_dev = loss_mean_dev / num_batches_per_epoch
                print('[dev loss:', loss_mean_dev, "]")

            em = float(np.mean(em_mean))
            if em > max_score:
                path = saver.save(self.sess, model_path + "/model", global_step=i)
                print("Saved model checkpoint to {}".format(path))
                max_score = em

    def _truncate_seq_pair(self, tokens_a, tokens_b, max_length):
        while True:
            total_length = len(tokens_a) + len(tokens_b)
            if total_length <= max_length:
                break
            if len(tokens_a) > len(tokens_b):
                tokens_a.pop()
            else:
                tokens_b.pop()

    def convert_single_example(self, max_seq_length, tokenizer, text_a, text_b=None):
        tokens_a = tokenizer.tokenize(text_a)
        tokens_b = None
        if text_b:
            tokens_b = tokenizer.tokenize(text_b)
        if tokens_b:
            self._truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
        else:
            if len(tokens_a) > max_seq_length - 2:
                tokens_a = tokens_a[0:(max_seq_length - 2)]

        tokens = []
        segment_ids = []
        tokens.append("[CLS]")
        segment_ids.append(0)
        for token in tokens_a:
            tokens.append(token)
            segment_ids.append(0)
        tokens.append("[SEP]")
        segment_ids.append(0)
        if tokens_b:
            for token in tokens_b:
                tokens.append(token)
                segment_ids.append(1)
            tokens.append("[SEP]")
            segment_ids.append(1)
        input_ids = tokenizer.convert_tokens_to_ids(tokens)
        input_mask = [1] * len(input_ids)
        while len(input_ids) < max_seq_length:
            input_ids.append(0)
            input_mask.append(0)
            segment_ids.append(0)
        assert len(input_ids) == max_seq_length
        assert len(input_mask) == max_seq_length
        assert len(segment_ids) == max_seq_length
        return input_ids, input_mask, segment_ids

    def load_dataset(self, names, tokens, ans_length, question_length, passage_length):
        def cut_length(sentence, length):
            return sentence[:length]

        def cut_length_from_back(sentence, length):
            return sentence[-length:]

        if type(names) is str:
            d = json.load(open(names, encoding='utf8'))
        else:
            d = []
            for name in names:
                d += json.load(open(name, encoding='utf8'))
        # d = d[:10]
        d_len = len(d)
        print("set size:", d_len)
        set_input = []
        set_input_mask = []
        set_input_seg = []
        set_label = []
        id_orig = []
        for line in tqdm(d, ncols=30):
            question, full_ans, label, qid = line['question'], line['candidates'], line['answer'], line['qid']
            input_id = []
            input_mask = []
            input_seg = []
            passage, tb = self.ret_model.run(question, full_ans)
            for index_ans, ans in enumerate(full_ans):
                passage_concat = cut_length('。'.join(passage[index_ans]), int(passage_length / 2))
                tb_length = int(passage_length / 2) if len(passage_concat) == int(passage_length / 2) \
                    else passage_length - len(passage_concat)
                tb_concat = cut_length(' '.join(tb[index_ans]), tb_length)
                input_ids_s, input_mask_s, segment_ids_s = self.convert_single_example(
                    passage_length + question_length + ans_length + 4,
                    tokens,
                    cut_length(passage_concat + tb_concat, passage_length)
                    + '[SEP]'
                    +
                    cut_length_from_back(str(question), question_length)
                    ,
                    cut_length(str(ans), ans_length))
                input_id.append(np.expand_dims(input_ids_s, 0))
                input_mask.append(np.expand_dims(input_mask_s, 0))
                input_seg.append(np.expand_dims(segment_ids_s, 0))

            input_id = np.vstack(input_id)
            input_mask = np.vstack(input_mask)
            input_seg = np.vstack(input_seg)

            set_input.append(input_id)
            set_input_mask.append(input_mask)
            set_input_seg.append(input_seg)
            set_label.append(label)

            id_orig.append(qid)
        set_input = np.array(set_input, dtype=np.int32)
        set_input_mask = np.array(set_input_mask, dtype=np.int32)
        set_input_seg = np.array(set_input_seg, dtype=np.int32)
        set_label = np.array(set_label, dtype=np.int32)
        print("set_input:", set_input.shape)
        print("set_label:", set_label.shape)

        return set_input, set_input_mask, set_input_seg, set_label, id_orig

    def get_result(self, logits, ids):
        def find_max_in_five(a):
            if a[0] == max(a):
                return 0
            if a[1] == max(a):
                return 1
            if a[2] == max(a):
                return 2
            if a[3] == max(a):
                return 3
            return 4

        result = {}
        for i, id in enumerate(ids):
            label_pred = find_max_in_five(logits[i])
            if label_pred == 0:
                label_pred = 'A'
            elif label_pred == 1:
                label_pred = 'B'
            elif label_pred == 2:
                label_pred = 'C'
            elif label_pred == 3:
                label_pred = 'D'
            else:
                label_pred = 'E'
            result[id] = [label_pred]
        return result

    def read_answers(self, path):
        id2letter = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E'}
        ans = {}
        data = json.load(open(path, encoding='utf8'))
        for d in data:
            ans[d['qid']] = id2letter[d['answer']]
        return ans

    def calculate_accuracy(self, true_ans, predicted):
        acc = 0
        for key in predicted:
            if true_ans[key] in predicted[key]:
                acc += 1
        return acc / len(predicted), acc


if __name__ == "__main__":
    # eval = Evaluation('bert', 'model/A1')
    # print(eval.run('123', ['1', '0', '9', '8', '7']))

    train = Train('/home1/bianning/bert/bert/tmp_extra_extra/pretraining_output_5000',
                  'output/tmp',
                  ["../../prepro_data/train_%s.json" % 'B1'],
                  ["../../prepro_data/testset2017_%s.json" % 'B1'])
